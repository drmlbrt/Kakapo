import shutil

def copy_orig_file():
    src = r'/PROD/templates/qos/pm_qos.cfg'
    dst = r'/PROD/templates/qos/new_pm_qos.cfg'
    shutil.copyfile(src, dst)
    replacestrings(dst)
    return dst


def replacestrings(dict_corp):
    dict_string = dict_corp
    # print(f"{dict_string}")
    dst = r'/PROD/templates/qos/new_pm_qos.cfg'

    with open(dst, 'r') as file:
        filedata = file.read()

        # Replace the target string
        for key in dict_string.keys():
            filedata = filedata.upper().replace(key, str(dict_string[key]))
            print(filedata)

        # Write the file out again
    with open('PM_QOS_NEW_test.txt', 'w') as file:
            file.write(filedata)
    return


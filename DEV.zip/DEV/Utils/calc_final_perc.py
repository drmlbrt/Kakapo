def calc_final_perc():
    return